INSERT INTO public.transactions (id, username, primary_ccy, secondary_ccy, rate, action, notional, tenor, date) VALUES (1, 'andrei', 'EUR', 'USD', 18459, 'BUY', 23, 'SP', '2018-11-13 20:56:11.59403');
INSERT INTO public.transactions (id, username, primary_ccy, secondary_ccy, rate, action, notional, tenor, date) VALUES (2, 'andrei', 'USD', 'GBP', 11701, 'BUY', 111, '1M', '2018-11-19 19:32:02.773998');
INSERT INTO public.transactions (id, username, primary_ccy, secondary_ccy, rate, action, notional, tenor, date) VALUES (3, 'andrei', 'EUR', 'GBP', 10957, 'BUY', 100, '1M', '2018-11-19 19:39:50.7525');
INSERT INTO public.transactions (id, username, primary_ccy, secondary_ccy, rate, action, notional, tenor, date) VALUES (4, 'andrei', 'EUR', 'GBP', 14298, 'BUY', 100, '1M', '2018-11-19 19:40:43.935658');
INSERT INTO public.transactions (id, username, primary_ccy, secondary_ccy, rate, action, notional, tenor, date) VALUES (5, 'andrei', 'EUR', 'GBP', 10640, 'BUY', 100, '1M', '2018-11-19 19:41:15.177145');
INSERT INTO public.transactions (id, username, primary_ccy, secondary_ccy, rate, action, notional, tenor, date) VALUES (6, 'andrei', 'USD', 'RON', 58966, 'BUY', 112, 'SP', '2018-11-19 19:41:49.361552');
INSERT INTO public.transactions (id, username, primary_ccy, secondary_ccy, rate, action, notional, tenor, date) VALUES (7, 'andrei', 'GBP', 'RON', 57622, 'BUY', 100, '3M', '2018-11-19 20:10:03.621845');
INSERT INTO public.transactions (id, username, primary_ccy, secondary_ccy, rate, action, notional, tenor, date) VALUES (8, 'andrei', 'EUR', 'USD', 13345, 'BUY', 11, '1M', '2018-11-19 20:11:50.19023');


